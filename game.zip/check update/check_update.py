import requests
from packaging import version
import os
import tkinter as tk

VERSION_FILE = "version.kli"
UPDATE_URL = "https://gist.githubusercontent.com/wintlerclicker/1d10709660d00882204fb0910dda8152/raw/versions"
BACKUP_SUFFIX = ".bak"

# Цвета и шрифты
BACKGROUND_COLOR = "#2E3440"  # Dark background
FOREGROUND_COLOR = "#D8DEE9"  # Light text
BUTTON_COLOR = "#5E81AC"      # Blueish buttons
BUTTON_TEXT_COLOR = "#ECEFF4"  # Lighter button text
FONT = ("Arial", 12)
TITLE_FONT = ("Arial", 14, "bold")

def get_current_version():
    """Читает текущую версию из файла version.kli."""
    try:
        with open(VERSION_FILE, "r") as f:
            current_version = f.read().strip()
        return current_version
    except FileNotFoundError:
        print(f"Файл {VERSION_FILE} не найден. Предполагается версия 0.0.0")
        return "0.0.0"
    except Exception as e:
        print(f"Ошибка при чтении файла {VERSION_FILE}: {e}")
        return None

def perform_update():
    """Обновляет файл version.kli."""
    try:
        response = requests.get(UPDATE_URL)
        response.raise_for_status()
        latest_version = response.text.strip()

        # 1. Создаем резервную копию старого файла
        try:
            os.rename(VERSION_FILE, VERSION_FILE + BACKUP_SUFFIX)
        except FileNotFoundError:
            print(f"Файл {VERSION_FILE} не найден, пропуск резервного копирования.")
        except OSError as e:
            print(f"Ошибка при создании резервной копии: {e}")
            update_label.config(text=f"Ошибка при создании резервной копии: {e}")
            return False

        # 2. Записываем новую версию в файл
        try:
            with open(VERSION_FILE, "w") as f:
                f.write(latest_version)
            print(f"{VERSION_FILE} успешно обновлен до версии {latest_version}")
            update_label.config(text=f"{VERSION_FILE} успешно обновлен до версии {latest_version}")
            return True
        except Exception as e:
            print(f"Ошибка при записи в файл {VERSION_FILE}: {e}")
            update_label.config(text=f"Ошибка при записи в файл {VERSION_FILE}: {e}")

            # Восстанавливаем резервную копию, если обновление не удалось
            try:
                os.rename(VERSION_FILE + BACKUP_SUFFIX, VERSION_FILE)
                print("Резервная копия восстановлена.")
                update_label.config(text="Резервная копия восстановлена.")
            except Exception as restore_error:
                print(f"Ошибка при восстановлении резервной копии: {restore_error}")
                update_label.config(text=f"Ошибка при восстановлении резервной копии: {restore_error}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"Ошибка при проверке обновления: {e}")
        update_label.config(text=f"Ошибка при проверке обновления: {e}")
        return False
    except Exception as e:
        print(f"Произошла непредвиденная ошибка: {e}")
        update_label.config(text=f"Произошла непредвиденная ошибка: {e}")
        return False

def update_yes():
    """Выполняет обновление, если пользователь нажал "Да"."""
    if perform_update():
        root.destroy()

def update_no():
    """Закрывает окно, если пользователь нажал "Нет"."""
    root.destroy()

def check_for_updates():
    """Проверяет наличие обновлений и отображает информацию в окне."""
    current_version = get_current_version()
    if current_version is None:
        update_label.config(text="Не удалось получить текущую версию.")
        return

    try:
        response = requests.get(UPDATE_URL)
        response.raise_for_status()
        latest_version = response.text.strip()

        if version.parse(latest_version) > version.parse(current_version):
            message = f"Доступна новая версия: {latest_version}\nТекущая версия: {current_version}\nОбновить сейчас?"
            update_label.config(text=message)
            yes_button.pack(pady=5)  # Добавляем отступ сверху и снизу
            no_button.pack(pady=5)   # Добавляем отступ сверху и снизу
        else:
            update_label.config(text="У вас установлена последняя версия.")

    except requests.exceptions.RequestException as e:
        update_label.config(text=f"Ошибка при проверке обновления: {e}")
    except Exception as e:
        update_label.config(text=f"Произошла непредвиденная ошибка: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Проверка обновлений")
    root.geometry("400x200")
    root.configure(bg=BACKGROUND_COLOR)  # Устанавливаем цвет фона для окна

    update_label = tk.Label(root, text="Проверка обновлений...", wraplength=380,
                            bg=BACKGROUND_COLOR, fg=FOREGROUND_COLOR, font=FONT) # Задаем шрифт и цвета
    update_label.pack(pady=10, padx=10)

    yes_button = tk.Button(root, text="Да", command=update_yes, width=10,
                           bg=BUTTON_COLOR, fg=BUTTON_TEXT_COLOR, font=FONT, relief=tk.RAISED) # Стиль для кнопки
    no_button = tk.Button(root, text="Нет", command=update_no, width=10,
                          bg=BUTTON_COLOR, fg=BUTTON_TEXT_COLOR, font=FONT, relief=tk.RAISED) # Стиль для кнопки

    check_for_updates()

    root.mainloop()
